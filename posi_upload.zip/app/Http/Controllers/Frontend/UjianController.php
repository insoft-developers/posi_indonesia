<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\ExamSession;
use App\Models\Transaction;
use App\Models\Ujian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UjianController extends Controller
{
    public function index($token)
    {
        $view = 'ujian';
        $session = ExamSession::with('competition','study.pelajaran')->where('token', $token)->first();
        $soal = Ujian::where('competition_id', $session->competition_id)
            ->where('study_id', $session->study_id)->get();
        return view('frontend.ujian', compact('view','session','soal'));
    }

    public function ujian_start(Request $request)
    {
        $input = $request->all();

        try {
            $transaction = Transaction::findorFail($input['id']);

            $unik = uniqid();
            $token = SHA1($unik);

            $data_input = [
                'transaction_id' => $input['id'],
                'invoice_id' => $transaction->invoice_id,
                'competition_id' => $transaction->competition_id,
                'study_id' => $transaction->study_id,
                'userid' => Auth::user()->id,
                'token' => $token
            ];

            $cek = ExamSession::where('transaction_id', $input['id'])->where('userid', Auth::user()->id);
            if($cek->count()>0) {
               ExamSession::where('transaction_id', $input['id'])->where('userid', Auth::user()->id)
                ->update($data_input);
            } else {
                ExamSession::create($data_input);
            }

            

            return response()->json([
                "success" => true,
                "message" => "success",
                "data" => $token
            ]);
        } catch ( \Exception $e) {
            return response()->json([
                "success" => false,
                "message" => $e->getMessage()
            ]);
        }
    }
}
