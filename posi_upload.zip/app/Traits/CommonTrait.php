<?php
namespace App\Traits;

trait CommonTrait
{
    
}
