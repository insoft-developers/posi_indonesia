

<?php $__env->startSection('content'); ?>
    <!-- Page Banner Start -->
    <div class="section page-banner">



    </div>
    <!-- Page Banner End -->

    <!-- About Start -->
    <div class="section">

        <div class="section-padding-02 mt-n10">
            <div class="container">
                <div class="section-title shape-03 text-center">
                    <h2 class="main-title">Daftar Transaksi</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <?php if($transaction->count() > 0): ?>
                            <table id="table-transaction" class="table table-bordered" style="font-size: 14px;">
                                <thead>
                                    <tr>
                                        <th>No Invoice</th>
                                        <th>Status</th>
                                        <th>Bukti Transfer</th>
                                        <th>Jumlah</th>
                                        <th>Bayar Dengan</th>
                                        <th>Berlaku Hingga</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>

                                <?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $inv_amount = \App\Models\Transaction::where('invoice', $t->invoice)->sum(
                                            'amount',
                                        );

                                    ?>

                                    <tr style="vertical-align: middle">
                                        <td width="20%"><a href="<?php echo e(url('show-invoice/' . $t->invoice)); ?>"><span
                                                    style="color:blue;text-decoration:underline"><?php echo e($t->invoice); ?></span></a>
                                        </td>
                                        <td width="15%">
                                            <?php if($t->total_amount > 0): ?>
                                                <?php if($t->payment_status == 1): ?>
                                                    <span style="color: green"><strong><i class="fa fa-check"></i>
                                                            PAID</strong></span>
                                                <?php else: ?>
                                                    <span style="color: orange">UNPAID</span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($t->payment_status == 1): ?>
                                                    <span style="color: green"><strong><i class="fa fa-check"></i>
                                                            APPROVED</strong></span>
                                                <?php else: ?>
                                                    <span style="color: orange">NOT APPROVED</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                        <td width="15%">
                                            <center>
                                                <?php if($t->total_amount > 0): ?>
                                                    <?php if($t->image == null && $t->payment_status != 1): ?>
                                                        <span><a onclick="bayar(<?php echo e($t->id); ?>)"
                                                                href="javascript:void(0);"><img class="small-upload"
                                                                    src="<?php echo e(asset('template/frontend/assets/umum/upload_icon.png')); ?>"><span
                                                                    class="upload-click">Upload</span></a></span>
                                                    <?php elseif($t->image == null && $t->payment_status == 1): ?>
                                                        <span>Online Payment</span>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(asset('template/frontend/assets/bukti_transfer/' . $t->image)); ?>"
                                                            target="_blank"><img class="image-bukti"
                                                                src="<?php echo e(asset('template/frontend/assets/bukti_transfer/' . $t->image)); ?>"></a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <span style="color: green"><strong><i class="fa fa-check"></i>
                                                            FREE</strong></span>
                                                <?php endif; ?>
                                            </center>
                                        </td>
                                        <td width="15%">
                                            <strong>
                                                <?php if($t->total_amount > 0): ?>
                                                    Rp. <?php echo e(number_format($inv_amount)); ?>

                                                <?php else: ?>
                                                    <span style="color: green"><strong><i class="fa fa-check"></i>
                                                            FREE</strong></span>
                                                <?php endif; ?>
                                            </strong>
                                        </td>
                                        <td width="15%"><?php echo e($t->payment_with == null ? 'no-payment' : $t->payment_with); ?>

                                        </td>
                                        <td width="25%"><?php echo e(date('d F Y H:i', strtotime($t->expired_time))); ?></td>
                                        <td>
                                            <?php if($t->total_amount > 0): ?>
                                                <?php if($t->payment_status == 1): ?>
                                                <?php else: ?>
                                                    <center><button onclick="payment(<?php echo e($t->id); ?>)"
                                                            class="btn-insoft bg-success">Bayar</button></center>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span style="color: green"><strong>
                                                        FREE</strong></span>
                                            <?php endif; ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tfoot>
                                    <tr>
                                        <th colspan="5" style="text-align: right;"></th>

                                        <th></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php else: ?>
                            <center><img src="<?php echo e(asset('template/frontend/assets/umum/empty_transaction.png')); ?>"
                                    class="empty-image"></center>
                            <center>
                                <p style="color: red;">Belum ada Transaksi</p>
                            </center>
                            <center><a href="<?php echo e(url('main')); ?>"><span style="color:blue">Buat pesanan sekarang</span></a>
                            </center>
                            <br>
                            <br>
                        <?php endif; ?>


                        <div style="margin-top:50px"></div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- About End -->
    <!-- Modal -->
    <div class="modal fade" id="modal-pembayaran" tabindex="-1" aria-labelledby="staticBackdropLabel"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-600">
            <div class="modal-content">


                <div class="modal-header">
                    <p class="modal-title"><span class="modal-head-title">Transfer Manual</span><br><span
                            class="modal-subtitle" id="modal-subtitle">Upload Bukti Transfer</span></p>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="<?php echo e(route('upload.bukti')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" id="transaction_id" name="transaction_id">
                        <center><img id="image-upload" class="upload-image"
                                src="<?php echo e(asset('template/frontend/assets/umum/upload_icon.png')); ?>"></center>
                        <input style="display: none;" type="file" id="image" name="image"
                            accept="*.jpg, *.jpeg, *.png" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-insoft bg-success">Submit</button>
                        <button type="button" data-bs-dismiss="modal" class="btn btn-insoft">Tutup</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
    <!-- end Modal -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel-job\posi\resources\views/frontend/transaction.blade.php ENDPATH**/ ?>