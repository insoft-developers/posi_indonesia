

<?php $__env->startSection('content'); ?>
    <!-- Page Banner Start -->
    <div class="section page-banner">



    </div>
    <!-- Page Banner End -->

    <!-- About Start -->
    <div class="section">

        <div class="section-padding-02 mt-n10">
            <div class="container">
                <div class="section-title shape-03 text-center">
                    <h2 class="main-title">Cart</h2>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <?php if($cart->count() > 0): ?>
                            <table class="table table-striped table-bordered" style="font-size: 14px;">
                                <?php
                                    $total_harga = 0;
                                ?>

                                <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                       
                                    ?>
                                    <tr style="vertical-align: middle">
                                        <td width="8%"><img class="image-cart"
                                                src="<?php echo e(asset('template/frontend/assets/kompetisi/' . $c->competition->image)); ?>">
                                        </td>
                                        <td width="35%">Pendaftaran <?php echo e($c->competition->title); ?>

                                            <?php echo e($c->premium == 1 ? 'Berbayar' : 'Gratis'); ?> + (Bonus
                                            Pembahasan)<br><?php echo e($c->user->name); ?> - SMAN 1 Tanjung Morawa</td>
                                        <td width="25%">
                                            <?php
                                                $detail = \App\Models\Cart::with('study.pelajaran', 'study.level')
                                                    ->where('userid', Auth::user()->id)
                                                    ->where('competition_id', $c->competition_id)
                                                    ->get();

                                                $html = "<ul style='list-style:inside'>";
                                                $subtotal = 0;
                                                foreach ($detail as $d) {
                                                    $html .=
                                                        '<li>' .
                                                        $d->study->pelajaran->name .
                                                        '  ' .
                                                        $d->study->level->level_name .
                                                        '<br><strong> Rp. ' .
                                                        number_format($c->competition->price) .
                                                        '</strong></li>';
                                                    $subtotal = $subtotal + $c->competition->price;
                                                    $total_harga = $total_harga + $c->competition->price;
                                                }
                                            ?>

                                            <?= $html ?>

                                        </td>
                                        <td><strong>Rp. <?php echo e(number_format($subtotal)); ?></strong></td>
                                        <td>
                                            <center><button onclick="hapus_cart(<?php echo e($c->competition_id); ?>)"
                                                    class="btn-insoft bg-danger">Hapus</button></center>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tfoot>
                                    <tr>
                                        <th colspan="3" style="text-align: right;">Total Harga</th>

                                        <th>Rp. <?php echo e(number_format($total_harga)); ?></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        <?php else: ?>
                            <center><img src="<?php echo e(asset('template/frontend/assets/umum/empty_cart.png')); ?>"
                                    class="empty-image"></center>
                            <center>
                                <p style="color: red;">Belum ada Pesanan</p>
                            </center>
                            <center><a href="<?php echo e(url('main')); ?>"><span style="color:blue">Buat pesanan sekarang</span></a>
                            </center>
                            <br>
                            <br>
                        <?php endif; ?>
                        <?php if($cart->count() > 0): ?>
                            <button onclick="pesan_sekarang()" class="btn btn-success">Pesan Sekarang</button>
                        <?php endif; ?>
                        <div style="margin-top:50px"></div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <!-- About End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel-job\posi\resources\views/frontend/cart.blade.php ENDPATH**/ ?>