<!DOCTYPE html>
<html>
<head>
    <title>POSI (Pusat Olimpiade Sains Indonesia)</title>
</head>
<body>
   
   <p>Yth. Bapak {{ $details['nama'] }}</p> 
   <p>Kode Passcode anda adalah {{ $details['passcode'] }} masukkan 6 angka ini untuk mengaktifkan akun anda </p>   
   <p>Terima kasih.

   <p>Salam, <br>Admin POSI</p>
</body>
</html>