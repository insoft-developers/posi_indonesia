@extends('frontend.master_ujian')

@section('content')
    <!-- Page Banner Start -->
    <div class="section page-banner">



    </div>
    <!-- Page Banner End -->

    <!-- About Start -->
    <div class="section">
        <input type="hidden" id="tanggal-ujian" value="{{ $session->competition->date }}">
        <input type="hidden" id="jam-selesai" value="{{ $session->study->finish_time }}">
        <div class="section-padding-02 mt-n10">
            <div class="container">
                <div class="section-title shape-03 text-center">


                </div>
                <div class="row" id="soal-container">
                    <div class="col-lg-12">
                        <div class="soal-wrapper">
                            <p class="no-soal">Soal No. <?= $soal[60]->question_number ?></p>
                            <p class="soal-title"><?= $soal[60]->question_title ?></p>
                        </div>
                        <div class="jawaban-wrapper">
                            <p class="pilih-jawaban">Pilih Salah Satu Jawaban :</p>
                            <div class="row">
                                <div class="col-md-6">
                                    <div onclick="selected(1)" id="jawaban-a" class="jawaban-item">A.
                                        <?= $soal[60]->option_a ?></div>
                                    <div onclick="selected(3)" id="jawaban-c" class="jawaban-item">C.
                                        <?= $soal[60]->option_c ?></div>
                                    <div onclick="selected(5)" id="jawaban-e" class="jawaban-item">E.
                                        <?= $soal[60]->option_e ?></div>
                                </div>
                                <div class="col-md-6">
                                    <div onclick="selected(2)" id="jawaban-b" class="jawaban-item">B.
                                        <?= $soal[60]->option_b ?></div>
                                    <div onclick="selected(4)" id="jawaban-d" class="jawaban-item">D.
                                        <?= $soal[60]->option_d ?></div>
                                    <div onclick="selected(6)" id="jawaban-f" class="jawaban-item">LEWATI</div>
                                </div>
                            </div>


                        </div>
                        <hr />
                        <button class="btn-sebelumnya-insoft">Sebelumnya</button>
                        <button class="btn-simpan-insoft">Simpan</button>
                        <div style="margin-top:150px;"></div>
                    </div>
                </div>
            </div>
        </div>


    </div>
@endsection
