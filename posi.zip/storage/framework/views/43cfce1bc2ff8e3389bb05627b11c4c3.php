<?php
    function hari_ini($tanggal)
    {
        $hari = date('D', strtotime($tanggal));

        switch ($hari) {
            case 'Sun':
                $hari_ini = 'Minggu';
                break;

            case 'Mon':
                $hari_ini = 'Senin';
                break;

            case 'Tue':
                $hari_ini = 'Selasa';
                break;

            case 'Wed':
                $hari_ini = 'Rabu';
                break;

            case 'Thu':
                $hari_ini = 'Kamis';
                break;

            case 'Fri':
                $hari_ini = 'Jumat';
                break;

            case 'Sat':
                $hari_ini = 'Sabtu';
                break;

            default:
                $hari_ini = 'Tidak di ketahui';
                break;
        }

        return $hari_ini;
    }

    function selisih_hari($tanggal)
    {
        $tanggal_1 = new DateTime();
        $tanggal_2 = new DateTime($tanggal);
        $selisih = $tanggal_1->diff($tanggal_2);
        return $selisih->d;
    }

?>




<?php $__env->startSection('content'); ?>
    <!-- Page Banner Start -->
    <div class="section page-banner">


    </div>
    <!-- Page Banner End -->

    <!-- Blog Start -->
    <div class="section section-padding mt-n10">
        <div class="container">
            <div class="section-title shape-03 text-center">
                <h2 class="main-title">Kompetisi Online</h2>
            </div>
            <!-- Blog Wrapper Start -->
            <div class="blog-wrapper">
                <div class="row">
                    <input type="hidden" id="jumlah_kompetisi" value="<?php echo e(count($kompetisi)); ?>">
                    <?php $__currentLoopData = $kompetisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6">

                            <!-- Single Blog Start -->
                            <div class="single-blog">
                                <div class="blog-image">
                                    <a href="blog-details-left-sidebar.html"><img
                                            src="<?php echo e(asset('template/frontend')); ?>/assets/kompetisi/<?php echo e($k->image); ?>"
                                            alt="Blog"></a>
                                </div>
                                <div class="blog-content">


                                    <h4 class="title"><a href="blog-details-left-sidebar.html"><?php echo e($k->title); ?></a></h4>

                                    <div class="blog-meta">
                                        <span> <i class="icofont-calendar"></i><?php echo e(hari_ini($k->date)); ?>,
                                            <?php echo e(date('d F Y', strtotime($k->date))); ?></span>
                                        <input type="hidden" id="waktu_<?php echo e($index); ?>" value="<?php echo e($k->finish_registration_date); ?> <?php echo e($k->finish_registration_time); ?>">
                                        <span class="sisa-hari" id="countdown_<?php echo e($index); ?>"></span>
                                        
                                    </div>
                                    <div class="garis"></div>
                                    <div class="blog-meta">
                                        <span> <i class="icofont-files-stack"></i>Masa Pendaftaran</span>
                                    </div>
                                    <div class="blog-note">
                                        <?php echo e(date('d F Y', strtotime($k->start_registration_date))); ?>

                                        <?php echo e(date('H:i', strtotime($k->start_registration_time))); ?> s.d
                                    </div>
                                    <div class="blog-note">
                                        <?php echo e(date('d F Y', strtotime($k->finish_registration_date))); ?>

                                        <?php echo e(date('H:i', strtotime($k->finish_registration_time))); ?>

                                    </div>
                                    <div class="blog-meta">
                                        <span> <i class="icofont-money"></i>Biaya Pendaftaran</span>
                                    </div>
                                    <div class="blog-note">
                                        <?php if($k->type == 1): ?>
                                            Rp. <?php echo e(number_format($k->price)); ?> atau gratis dengan syarat
                                        <?php elseif($k->type == 2): ?>
                                            Rp. <?php echo e(number_format($k->price)); ?>

                                        <?php elseif($k->type == 2): ?>
                                            Gratis
                                        <?php endif; ?>

                                    </div>
                                    <div class="blog-meta">
                                        <span> <i class="icofont-link"></i>Link Juknis</span>
                                    </div>
                                    <div class="blog-note">
                                        <a href="">Lihat juknis disini</a>
                                    </div>
                                    <div class="garis"></div>
                                    <button id="btn_daftar_<?php echo e($index); ?>" href="javascript:void(0);" onclick="daftar(<?php echo e($k->id); ?>)"
                                        class="btn btn-secondary btn-hover-primary">Daftar</button>
                                    <span class="foot-note">1.450 Pedaftar</span>
                                </div>
                            </div>
                            <!-- Single Blog End -->

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <!-- Blog Wrapper End -->

            <!-- Page Pagination End -->
            
            <!-- Page Pagination End -->

        </div>
    </div>
    <!-- Blog End -->


    <!-- Modal -->
    <div class="modal fade" id="modal-daftar" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered">
            <div class="modal-content modal-transparent">
                <input type="hidden" id="competition_id">

                <div class="modal-body">
                    <center>
                        <div onclick="personal_register()" class="tombol-daftar"><i class="fa fa-user"></i> Pendaftaran
                            Personal</div>
                    </center>
                    <center>
                        <div onclick="collective_register()" class="tombol-daftar"><i class="fa fa-users"></i> Pendaftaran
                            Kolektif</div>
                    </center>
                </div>

            </div>
        </div>
    </div>
    <!-- end Modal -->


    <!-- Modal -->
    <div class="modal fade" id="modal-daftar-list" tabindex="-1" aria-labelledby="staticBackdropLabel"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-600">
            <div class="modal-content">


                <div class="modal-header">
                    <p class="modal-title"><span class="modal-head-title"><?php echo e(Auth::user()->name); ?></span><br><span
                            class="modal-subtitle" id="modal-subtitle">Pendaftaran Event</span></p>

                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="modal-daftar-list-content"></div>
                </div>
                <div class="modal-footer">
                    <button onclick="syarat_gratis()" type="button" class="btn btn-warning btn-sm">Gratis</button>
                    <button onclick="simpan_bayar()" type="button" class="btn btn-primary btn-sm">Berbayar</button>
                </div>

            </div>
        </div>
    </div>



    <!-- Modal -->
    <div class="modal fade" id="modal-gratis" tabindex="-1" aria-labelledby="staticBackdropLabel"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-600">
            <div class="modal-content">

                <form method="POST" id="form-gratis-submit" name="form-gratis-submit" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <p class="modal-title"><span class="modal-head-title"><?php echo e(Auth::user()->name); ?></span><br><span
                                class="modal-subtitle" id="modal-subtitle">Syarat Pendaftaran</span></p>

                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Follow Instagram @posi</label>
                            <div style="margin-top:10px;"></div>
                            <input type="file" id="file1" name="files[]" accept="*.jpg, *.jpeg, *.png" required
                                style="display: none;">
                            <img id="image-syarat1" src="<?php echo e(asset('template/frontend/assets/umum/upload_icon.png')); ?>"
                                class="upload-syarat">
                        </div>
                        <hr />
                        <div class="form-group">
                            <label>Unduh aplikasi Posi di Playstore</label>
                            <div style="margin-top:10px;"></div>
                            <input type="file" id="file2" name="files[]" accept="*.jpg, *.jpeg, *.png" required
                                style="display: none;">
                            <img id="image-syarat2" src="<?php echo e(asset('template/frontend/assets/umum/upload_icon.png')); ?>"
                                class="upload-syarat">
                        </div>
                        <hr />
                        <div class="form-group">
                            <label>Komen pendapat posiitf kamu tentang POSI kemudian tag 5 teman kamu di positingan
                                ini.</label>
                            <div style="margin-top:10px;"></div>
                            <input type="file" id="file3" name="files[]" accept="*.jpg, *.jpeg, *.png" required
                                style="display: none;">
                            <img id="image-syarat3" src="<?php echo e(asset('template/frontend/assets/umum/upload_icon.png')); ?>"
                                class="upload-syarat">
                        </div>
                    </div>
                    <div class="modal-footer">

                        <button type="submit" class="btn btn-primary btn-sm">Daftar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel-job\posi\resources\views/frontend/main.blade.php ENDPATH**/ ?>