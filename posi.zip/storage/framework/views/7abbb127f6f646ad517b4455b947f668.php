<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>POSI - Indonesia</title>
    <meta name="robots" content="noindex, follow" />
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('midtrans.client_key')); ?>">
    </script>


    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('template/frontend')); ?>/assets/images/pav.png">

    <!-- CSS
 ============================================ -->

    <!-- Google Fonts CSS -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/icofont.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/flaticon.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/font-awesome.min.css">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/animate.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/swiper-bundle.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/apexcharts.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/plugins/jqvmap.min.css">
    <link rel="stylesheet" href=" https://cdn.datatables.net/2.1.8/css/dataTables.dataTables.min.css">


    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/style.css">


    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/vendor/plugins.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('template/frontend')); ?>/assets/css/style.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />



    <?php echo $__env->make('frontend.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>


    <div class="main-wrapper">

        <!-- Header Section Start -->
        <div class="header-section">

           

            <!-- Header Main Start -->
            <div class="header-main">
                <div class="container">

                    <!-- Header Main Start -->
                    <div class="header-main-wrapper">

                        <!-- Header Logo Start -->
                        <div class="header-logo">
                            <a href="<?php echo e(url('/')); ?>"><img
                                    src="<?php echo e(asset('template/frontend')); ?>/assets/images/logo.png" alt="Logo"></a>
                        </div>
                        <!-- Header Logo End -->

                        <!-- Header Menu Start -->
                       
                        <div class="header-menu d-none d-lg-block">
                           
                            
                        </div>
                      

                        <!-- Header Mobile Toggle Start -->
                        
                        <!-- Header Mobile Toggle End -->

                    </div>
                    <!-- Header Main End -->

                </div>
            </div>
            <!-- Header Main End -->

        </div>
        <!-- Header Section End -->

        <!-- Mobile Menu Start -->
        
        <!-- Mobile Menu End -->

        <!-- Overlay Start -->
        <div class="overlay"></div>
        <!-- Overlay End -->

        <!-- Slider Start -->


        <?php echo $__env->yieldContent('content'); ?>



      

        <!--Back To Start-->
        <a href="#" class="back-to-top">
            <i class="icofont-simple-up"></i>
        </a>
        <!--Back To End-->

    </div>






    <!-- JS
    ============================================ -->

    <!-- Modernizer & jQuery JS -->
    <script src="<?php echo e(asset('template/frontend')); ?>/assets/js/vendor/modernizr-3.11.2.min.js"></script>
    <script src="<?php echo e(asset('template/frontend')); ?>/assets/js/vendor/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/2.1.8/js/dataTables.min.js"></script>

    <!-- Bootstrap JS -->
    

    <!-- Plugins JS -->
    

    <!--====== Use the minified version files listed below for better performance and remove the files listed above ======-->
    <script src="<?php echo e(asset('template/frontend')); ?>/assets/js/plugins.min.js"></script>


    <!-- Main JS -->
    <script src="<?php echo e(asset('template/frontend')); ?>/assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>

   

    <?php echo $__env->make('frontend.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH C:\laravel-job\posi\resources\views/frontend/master_selesai.blade.php ENDPATH**/ ?>