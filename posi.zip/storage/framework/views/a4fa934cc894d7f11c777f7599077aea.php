<?php
    function hari_ini($tanggal)
    {
        $hari = date('D', strtotime($tanggal));

        switch ($hari) {
            case 'Sun':
                $hari_ini = 'Minggu';
                break;

            case 'Mon':
                $hari_ini = 'Senin';
                break;

            case 'Tue':
                $hari_ini = 'Selasa';
                break;

            case 'Wed':
                $hari_ini = 'Rabu';
                break;

            case 'Thu':
                $hari_ini = 'Kamis';
                break;

            case 'Fri':
                $hari_ini = 'Jumat';
                break;

            case 'Sat':
                $hari_ini = 'Sabtu';
                break;

            default:
                $hari_ini = 'Tidak di ketahui';
                break;
        }

        return $hari_ini;
    }

    function selisih_hari($tanggal)
    {
        $tanggal_1 = new DateTime();
        $tanggal_2 = new DateTime($tanggal);
        $selisih = $tanggal_1->diff($tanggal_2);
        return $selisih->d;
    }

?>





<?php $__env->startSection('content'); ?>
    <!-- Page Banner Start -->
    <div class="section page-banner">


    </div>
    <!-- Page Banner End -->

    <!-- Blog Start -->
    <div class="section section-padding mt-n10">
        <div class="container">
            <div class="section-title shape-03 text-center">
                <h2 class="main-title">Jadwal Ujian</h2>
            </div>
            <!-- Blog Wrapper Start -->
            <div class="blog-wrapper">
                <?php
                    $nomor = 0;
                ?>
                <?php if($data->count() > 0): ?>
                <div class="row">
                    <?php
                    $nomor = -1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 col-md-6">

                            <!-- Single Blog Start -->

                            <div class="single-blog">
                               
                                <div class="row">
                                    <div class="col-md-5 col-md-5">
                                        <a href="#"><img class="jadwal-image"
                                                src="<?php echo e(asset('template/frontend/assets/kompetisi/' . $d->image . '')); ?>"
                                                alt="Competition Image"></a>
                                        <div class="blog-content">
                                            <h4 class="jadwal-title"><a
                                                    href="blog-details-left-sidebar.html"><?php echo e($d->title); ?></a></h4>
                                            <div class="author-name">
                                                <a class="name" href="#"><?php echo e(hari_ini($d->date)); ?>,
                                                    <?php echo e(date('d F Y', strtotime($d->date))); ?></a>
                                            </div>
                                            <div class="author-name">
                                                <a class="name" href="#"><?php echo e($d->levels->level_name); ?>,
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-7 col-md-7">
                                        <div class="blog-content">

                                            <?php $__currentLoopData = $d->transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                $nomor++;
                                                ?>
                                                <div> <i class="icofont-calendar"></i> <?php echo e($t->study->pelajaran->name); ?>

                                                </div>
                                                <div class="sub-info"> <?php echo e(date('d F Y', strtotime($d->date))); ?> -
                                                    <?php echo e(date('H:i', strtotime($t->study->start_time))); ?> s/d
                                                    <?php echo e(date('H:i', strtotime($t->study->finish_time))); ?></div>
                                                <div class="sub-info">
                                                    <div class="row">
                                                        <div style="color: #0fa4c9;" class="col-lg-6 col-md-6"><strong><i class="icofont-telegram"></i><a href="#">Link Group</a></strong></div>
                                                        <div style="color: #ce0404;" class="col-lg-6 col-md-6"><strong><i class="icofont-clock-time"></i> <span id="countdown_<?php echo e($nomor); ?>"></span></strong></div>
                                                        <input type="hidden" id="tanggal_<?php echo e($nomor); ?>" value="<?php echo e($d->date); ?>">
                                                        <input type="hidden" id="jam_<?php echo e($nomor); ?>" value="<?php echo e($t->study->start_time); ?>">
                                                        <input type="hidden" id="selesai_<?php echo e($nomor); ?>" value="<?php echo e($t->study->finish_time); ?>">
                                                        <p onclick="ikut_ujian(<?php echo e($t->id); ?>)" style="display: none;" class="button-ujian" id="tombol_ujian_<?php echo e($nomor); ?>">Mulai Ujian</p>
                                                    </div>
                                                </div>
                                                <div class="minus-15"></div>
                                                <hr />
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                            
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Single Blog End -->

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php else: ?>
                <center><img src="<?php echo e(asset('template/frontend/assets/umum/empty_transaction.png')); ?>"
                    class="empty-image"></center>
            <center>
                <p style="color: red;">Belum ada Jadwal</p>
            </center>
            <center><a href="<?php echo e(url('main')); ?>"><span style="color:blue">Buat pesanan sekarang</span></a>
            </center>
            <br>
            <br>
                <?php endif; ?>
            </div>
            <!-- Blog Wrapper End -->


        </div>
    </div>
    <!-- Blog End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel-job\posi\resources\views/frontend/jadwal.blade.php ENDPATH**/ ?>